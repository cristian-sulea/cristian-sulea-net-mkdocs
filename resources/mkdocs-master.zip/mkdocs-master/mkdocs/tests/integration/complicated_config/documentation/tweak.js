console.log("JavaScript loaded");
